<?php

namespace ShellaiDev\Interfaces\Models;

interface IParams {

    /** Set params */
    public function setParams($params);

    /** Get params */
    public function getParams();

}

?>